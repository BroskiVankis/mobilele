package bg.softuni.mobilele;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileleApplicationTests {

	@Test
	void contextLoads() {
	}

}
